package com.jarvis.ai;

import android.content.SharedPreferences;

import org.json.JSONObject;

import java.util.Iterator;

/** Несекретные настройки приложения (хранятся в SharedPreferences одним JSON). */
final class JarvisSettings {
    static final String DEFAULT_SYSTEM =
            "Ты JARVIS — спокойный, точный и дружелюбный персональный ИИ-помощник. "
            + "Отвечай по существу, ясно и кратко, если не просят подробно. "
            + "Если не уверен — честно скажи об этом.";

    private final SharedPreferences prefs;

    JarvisSettings(SharedPreferences prefs) {
        this.prefs = prefs;
    }

    static JSONObject defaults() {
        JSONObject o = new JSONObject();
        try {
            o.put("mode", "own");              // own | free
            o.put("provider", "openrouter");   // openrouter | custom
            o.put("customBaseUrl", "");
            o.put("model", "openrouter/auto");
            o.put("systemPrompt", DEFAULT_SYSTEM);
            o.put("lang", "auto");             // auto | ru | az | tr | en
            o.put("ttsEngine", "system");      // system | online
            o.put("perf", "auto");             // auto | full | lite
            o.put("ttsRate", 0.95);
            o.put("ttsPitch", 0.85);
            o.put("voices", new JSONObject());
            o.put("autoSpeak", false);
        } catch (Exception ignored) {
        }
        return o;
    }

    synchronized JSONObject all() {
        JSONObject o = defaults();
        try {
            JSONObject saved = new JSONObject(prefs.getString("settings_json", "{}"));
            Iterator<String> it = saved.keys();
            while (it.hasNext()) {
                String k = it.next();
                if (o.has(k)) o.put(k, saved.get(k));
            }
        } catch (Exception ignored) {
        }
        return o;
    }

    synchronized void merge(JSONObject patch) {
        try {
            JSONObject cur = all();
            Iterator<String> it = patch.keys();
            while (it.hasNext()) {
                String k = it.next();
                if (cur.has(k)) cur.put(k, patch.get(k));
            }
            prefs.edit().putString("settings_json", cur.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    String str(String key) {
        return all().optString(key, "");
    }

    String voiceFor(String lang) {
        JSONObject v = all().optJSONObject("voices");
        return v == null ? "" : v.optString(lang, "");
    }

    synchronized void setVoice(String lang, String name) {
        try {
            JSONObject cur = all();
            JSONObject v = cur.optJSONObject("voices");
            if (v == null) v = new JSONObject();
            v.put(lang, name);
            cur.put("voices", v);
            prefs.edit().putString("settings_json", cur.toString()).apply();
        } catch (Exception ignored) {
        }
    }
}
