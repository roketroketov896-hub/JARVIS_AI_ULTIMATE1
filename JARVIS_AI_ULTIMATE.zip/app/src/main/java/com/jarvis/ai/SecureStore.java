package com.jarvis.ai;

import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Хранилище API-ключей. Ключ шифруется AES-GCM, а сам AES-ключ лежит в Android Keystore
 * (не извлекается приложением). Если Keystore недоступен, ключ держится только в памяти
 * до закрытия приложения и на диск открытым текстом не пишется.
 */
final class SecureStore {
    private static final String ALIAS = "jarvis_api_keys_v1";
    private final SharedPreferences prefs;
    private final Map<String, String> memoryOnly = new HashMap<>();

    SecureStore(SharedPreferences prefs) {
        this.prefs = prefs;
        migrateLegacy();
    }

    /** Старые версии хранили ключ открытым текстом под именем "apiKey": шифруем и удаляем. */
    private void migrateLegacy() {
        String legacy = prefs.getString("apiKey", "");
        if (legacy != null && !legacy.isEmpty()) {
            put("openrouter", legacy);
            prefs.edit().remove("apiKey").apply();
        }
    }

    private SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (!ks.containsAlias(ALIAS)) {
            KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            kg.init(new KeyGenParameterSpec.Builder(ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build());
            kg.generateKey();
        }
        return (SecretKey) ks.getKey(ALIAS, null);
    }

    synchronized void put(String name, String plain) {
        if (plain == null || plain.isEmpty()) {
            clear(name);
            return;
        }
        try {
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.ENCRYPT_MODE, key());
            byte[] iv = c.getIV();
            byte[] ct = c.doFinal(plain.getBytes(StandardCharsets.UTF_8));
            String packed = Base64.encodeToString(iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(ct, Base64.NO_WRAP);
            prefs.edit().putString("sk_" + name, packed).apply();
            memoryOnly.remove(name);
        } catch (Exception e) {
            memoryOnly.put(name, plain);
            prefs.edit().remove("sk_" + name).apply();
        }
    }

    synchronized String get(String name) {
        String mem = memoryOnly.get(name);
        if (mem != null) return mem;
        String packed = prefs.getString("sk_" + name, "");
        if (packed == null || packed.isEmpty()) return "";
        try {
            int sep = packed.indexOf(':');
            byte[] iv = Base64.decode(packed.substring(0, sep), Base64.NO_WRAP);
            byte[] ct = Base64.decode(packed.substring(sep + 1), Base64.NO_WRAP);
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, iv));
            return new String(c.doFinal(ct), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "";
        }
    }

    synchronized boolean has(String name) {
        return !get(name).isEmpty();
    }

    synchronized void clear(String name) {
        memoryOnly.remove(name);
        prefs.edit().remove("sk_" + name).apply();
    }
}
