package com.jarvis.ai;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

/**
 * Аудиофокус для озвучивания. Потеря фокуса (звонок, другое приложение) и отключение наушников
 * (ACTION_AUDIO_BECOMING_NOISY) вызывают паузу, чтобы JARVIS не продолжал говорить вслух неожиданно.
 */
final class AudioFocusHelper {
    private final Context ctx;
    private final AudioManager am;
    private final Handler main = new Handler(Looper.getMainLooper());
    private AudioFocusRequest request;
    private volatile Runnable onLoss;
    private boolean held = false;
    private boolean receiverOn = false;

    private final AudioManager.OnAudioFocusChangeListener listener = new AudioManager.OnAudioFocusChangeListener() {
        @Override
        public void onAudioFocusChange(int change) {
            if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) fireLoss();
        }
    };

    private final BroadcastReceiver noisy = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent != null && AudioManager.ACTION_AUDIO_BECOMING_NOISY.equals(intent.getAction())) fireLoss();
        }
    };

    AudioFocusHelper(Context context) {
        this.ctx = context.getApplicationContext();
        this.am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
    }

    private void fireLoss() {
        final Runnable r = onLoss;
        if (r != null) main.post(r);
    }

    /** Главный поток. */
    void acquire(Runnable lossAction) {
        onLoss = lossAction;
        if (!held && am != null) {
            if (Build.VERSION.SDK_INT >= 26) {
                request = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                        .setAudioAttributes(new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                        .setOnAudioFocusChangeListener(listener)
                        .build();
                am.requestAudioFocus(request);
            } else {
                am.requestAudioFocus(listener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK);
            }
            held = true;
        }
        if (!receiverOn) {
            try {
                ctx.registerReceiver(noisy, new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY));
                receiverOn = true;
            } catch (Exception ignored) {
            }
        }
    }

    /** Главный поток. */
    void release() {
        onLoss = null;
        if (held && am != null) {
            if (Build.VERSION.SDK_INT >= 26) {
                if (request != null) am.abandonAudioFocusRequest(request);
            } else {
                am.abandonAudioFocus(listener);
            }
            held = false;
        }
        if (receiverOn) {
            try {
                ctx.unregisterReceiver(noisy);
            } catch (Exception ignored) {
            }
            receiverOn = false;
        }
    }
}
