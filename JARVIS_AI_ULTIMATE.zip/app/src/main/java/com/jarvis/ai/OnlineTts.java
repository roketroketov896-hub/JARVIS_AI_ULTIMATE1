package com.jarvis.ai;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * Нейро-голос: текст режется на фразы, каждая фраза запрашивается у сервера JARVIS (/v1/tts, мужской голос
 * по языку), следующая фраза подгружается заранее. Пауза настоящая (MediaPlayer.pause), продолжение
 * идёт с того же места. Ключ сервиса речи хранится только на сервере. Методы вызывать из главного потока.
 */
final class OnlineTts {
    interface Source {
        /** Базовый адрес сервера JARVIS (https) или пустая строка. */
        String baseUrl();

        /** Действующий Google ID-токен или пустая строка. БЛОКИРУЮЩИЙ: вызывается из фонового потока. */
        String token();
    }

    private static final class TtsException extends Exception {
        final String code;

        TtsException(String code, String message) {
            super(message);
            this.code = code;
        }
    }

    private final Context ctx;
    private final Emitter emitter;
    private final Source source;
    private final AudioFocusHelper focus;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService fetchPool = Executors.newFixedThreadPool(2);
    private final ExecutorService waiter = Executors.newSingleThreadExecutor();
    private final Map<Integer, Future<File>> fetches = new HashMap<Integer, Future<File>>();

    private volatile int gen = 0;
    private List<String> segments = new ArrayList<String>();
    private int index = 0;
    private String msgId = "";
    private String lang = "ru";
    private String state = "idle";
    private MediaPlayer player;
    private boolean prepared = false;
    private File pendingFile;
    private int pendingIndex = 0;

    OnlineTts(Context ctx, Emitter emitter, Source source) {
        this.ctx = ctx.getApplicationContext();
        this.emitter = emitter;
        this.source = source;
        this.focus = new AudioFocusHelper(ctx);
    }

    boolean isActive() {
        return !"idle".equals(state);
    }

    private void emitState() {
        JSONObject d = new JSONObject();
        try {
            d.put("state", state);
            d.put("msgId", msgId);
            d.put("index", index);
            d.put("total", segments.size());
        } catch (Exception ignored) {
        }
        emitter.emit("tts", d);
    }

    private void emitError(String code, String message) {
        JSONObject d = new JSONObject();
        try {
            d.put("code", code);
            d.put("message", message);
            d.put("lang", lang);
        } catch (Exception ignored) {
        }
        emitter.emit("ttsError", d);
    }

    void speak(String id, String text, String language) {
        stopInternal();
        List<String> segs = TtsController.split(text);
        msgId = id;
        lang = (language == null || language.isEmpty()) ? "ru" : language;
        if (segs.isEmpty()) {
            state = "idle";
            emitState();
            return;
        }
        segments = segs;
        index = 0;
        gen++;
        state = "speaking";
        emitState();
        focus.acquire(new Runnable() {
            @Override
            public void run() {
                pause();
            }
        });
        startSegment(0);
    }

    private void prefetch(final int i, final int g) {
        if (i >= segments.size() || fetches.containsKey(i)) return;
        final String seg = segments.get(i);
        final String lg = lang;
        fetches.put(i, fetchPool.submit(new Callable<File>() {
            @Override
            public File call() throws Exception {
                return fetch(seg, lg, g);
            }
        }));
    }

    private void startSegment(final int i) {
        final int g = gen;
        prefetch(i, g);
        prefetch(i + 1, g);
        final Future<File> f = fetches.get(i);
        if (f == null) return;
        waiter.execute(new Runnable() {
            @Override
            public void run() {
                File file = null;
                Exception error = null;
                try {
                    file = f.get(60, TimeUnit.SECONDS);
                } catch (Exception e) {
                    error = e;
                }
                final File ready = file;
                final Exception failure = error;
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        if (g != gen) {
                            if (ready != null) ready.delete();
                            return;
                        }
                        if (failure != null || ready == null) {
                            fail(failure);
                            return;
                        }
                        play(i, ready, g);
                    }
                });
            }
        });
    }

    private void play(final int i, final File file, final int g) {
        if ("paused".equals(state)) {
            pendingFile = file;
            pendingIndex = i;
            return;
        }
        releasePlayer();
        index = i;
        MediaPlayer mp = new MediaPlayer();
        try {
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
            mp.setDataSource(file.getAbsolutePath());
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer m) {
                    file.delete();
                    if (g != gen) return;
                    fetches.remove(i);
                    if (i + 1 < segments.size()) startSegment(i + 1);
                    else {
                        releasePlayer();
                        state = "idle";
                        focus.release();
                        emitState();
                    }
                }
            });
            mp.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(MediaPlayer m, int what, int extra) {
                    file.delete();
                    if (g == gen) fail(null);
                    return true;
                }
            });
            mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer m) {
                    prepared = true;
                    if (g == gen && "speaking".equals(state)) m.start();
                }
            });
            player = mp;
            prepared = false;
            mp.prepareAsync();
            emitState();
        } catch (Exception e) {
            file.delete();
            try {
                mp.release();
            } catch (Exception ignored) {
            }
            fail(e);
        }
    }

    void pause() {
        if (!"speaking".equals(state)) return;
        state = "paused";
        try {
            if (player != null && prepared && player.isPlaying()) player.pause();
        } catch (Exception ignored) {
        }
        focus.release();
        emitState();
    }

    void resume() {
        if (!"paused".equals(state)) return;
        state = "speaking";
        focus.acquire(new Runnable() {
            @Override
            public void run() {
                pause();
            }
        });
        try {
            if (pendingFile != null) {
                File f = pendingFile;
                pendingFile = null;
                play(pendingIndex, f, gen);
            } else if (player != null && prepared) {
                player.start();
            }
        } catch (Exception e) {
            fail(e);
            return;
        }
        emitState();
    }

    void stop() {
        boolean was = isActive();
        stopInternal();
        if (was) emitState();
    }

    private void stopInternal() {
        gen++;
        state = "idle";
        releasePlayer();
        for (Future<File> f : fetches.values()) {
            f.cancel(true);
            try {
                if (f.isDone() && !f.isCancelled()) {
                    File file = f.get();
                    if (file != null) file.delete();
                }
            } catch (Exception ignored) {
            }
        }
        fetches.clear();
        if (pendingFile != null) {
            pendingFile.delete();
            pendingFile = null;
        }
        focus.release();
    }

    private void releasePlayer() {
        if (player != null) {
            try {
                player.release();
            } catch (Exception ignored) {
            }
            player = null;
            prepared = false;
        }
    }

    void shutdown() {
        stopInternal();
        fetchPool.shutdownNow();
        waiter.shutdownNow();
    }

    private void fail(Exception e) {
        String code = "online_failed";
        String message = "Не удалось получить нейро-голос от сервера. Проверь соединение или выбери системный голос в настройках.";
        Throwable t = e;
        while (t != null) {
            if (t instanceof TtsException) {
                code = ((TtsException) t).code;
                message = t.getMessage();
                break;
            }
            t = t.getCause();
        }
        stopInternal();
        emitState();
        emitError(code, message);
    }

    /** Фоновый поток: запрашивает аудио фразы и сохраняет во временный файл. */
    private File fetch(String text, String language, int g) throws Exception {
        String base = source.baseUrl();
        if (base.isEmpty()) throw new TtsException("not_configured", "Адрес сервера JARVIS не настроен, нейро-голос недоступен.");
        String token = source.token();
        if (token.isEmpty()) throw new TtsException("auth_required", "Для нейро-голоса нужен вход через Google.");
        HttpURLConnection conn = (HttpURLConnection) new URL(base + "/v1/tts").openConnection();
        try {
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(30000);
            conn.setDoOutput(true);
            conn.setRequestProperty("Authorization", "Bearer " + token);
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            JSONObject body = new JSONObject();
            body.put("text", text);
            body.put("lang", language);
            try (OutputStream os = conn.getOutputStream()) {
                os.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }
            int status = conn.getResponseCode();
            if (status != 200) {
                if (status == 429) throw new TtsException("tts_limit", "Дневной лимит нейро-голоса исчерпан. Выбери системный голос в настройках.");
                if (status == 503) throw new TtsException("not_configured", "Нейро-голос не настроен на сервере.");
                if (status == 403) throw new TtsException("blocked", "Доступ к серверу JARVIS заблокирован администратором.");
                if (status == 401) throw new TtsException("auth_required", "Нужно войти через Google заново.");
                throw new TtsException("online_failed", "Сервер нейро-голоса вернул ошибку " + status + ".");
            }
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            try (InputStream in = conn.getInputStream()) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            }
            if (g != gen) throw new TtsException("cancelled", "");
            File f = File.createTempFile("jtts", ".mp3", ctx.getCacheDir());
            try (FileOutputStream fos = new FileOutputStream(f)) {
                fos.write(bos.toByteArray());
            }
            return f;
        } finally {
            conn.disconnect();
        }
    }
}
