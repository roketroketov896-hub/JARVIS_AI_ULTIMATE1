# JARVIS AI ULTIMATE
Модули: `app` (пользовательское), `admin` (админ-панель), `backend` (сервер), `tests`. См. SETUP_RU.txt и REPORT_RU.md.
Gradle 8.7, AGP 8.6.1, JDK 17, compileSdk/targetSdk 34, minSdk 23.
