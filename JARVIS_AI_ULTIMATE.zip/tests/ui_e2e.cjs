// Автотест интерфейса пользовательского приложения в headless Chromium с имитацией Android-моста.
// Запуск: PLAYWRIGHT=/путь/к/playwright node tests/ui_e2e.cjs   (Android, Google и сервер здесь имитируются)
const path = require('path');
const assert = require('assert');
const { chromium } = require(process.env.PLAYWRIGHT || 'playwright');
const PAGE = 'file://' + path.resolve(__dirname, '../app/src/main/assets/index.html');
let passed = 0; const ok = (name) => { passed++; console.log('  ✓', name); };

async function boot(browser, opts = {}) {
  const ctx = await browser.newContext({ viewport: { width: opts.w || 390, height: opts.h || 800 } });
  const p = await ctx.newPage();
  p.errors = []; p.on('pageerror', (e) => p.errors.push(e.message));
  await p.addInitScript((o) => {
    window.__calls = []; window.__keys = { openrouter: true };
    const state = { settings: { mode: 'own', provider: 'openrouter', model: 'openrouter/auto', lang: 'auto', ttsRate: .95, ttsPitch: .85, ttsEngine: 'system', perf: 'auto', voices: {}, systemPrompt: '' },
      profile: o.signedIn ? { signedIn: true, email: 'me@x', name: 'Me' } : { signedIn: false }, configured: { backend: o.backend !== false, google: o.google !== false }, online: true, ttsReady: true };
    window.JarvisBridge = new Proxy({}, { get: (_, n) => (...a) => {
      window.__calls.push([n, ...a]);
      if (n === 'getState') return JSON.stringify(state);
      if (n === 'hasKey') return !!window.__keys[a[0]];
      if (n === 'saveApiKey') { window.__keys[a[0]] = true; return true; }
      if (n === 'getVoices') return '[]';
      if (n === 'saveSettings') Object.assign(state.settings, JSON.parse(a[0]));
      if (n === 'signIn') setTimeout(() => window.JarvisEvents.emit('auth', JSON.stringify({ signedIn: true, email: 'me@x', name: 'Me' })), 20);
      if (n === 'sendChat') window.__lastReq = a[0];
      return null;
    } });
    if (o.keepStorage !== true) { try { localStorage.setItem('jarvis_key_prompt_skipped', '1'); } catch (e) { /* ignore */ } }
  }, opts);
  await p.goto(PAGE); await p.waitForTimeout(250);
  return p;
}
const emit = (p, ev, d) => p.evaluate(([e, x]) => window.JarvisEvents.emit(e, JSON.stringify(x)), [ev, d]);
const calls = (p, n) => p.evaluate((nm) => window.__calls.filter((c) => c[0] === nm), n);

(async () => {
  const browser = await chromium.launch();

  console.log('Вход (обязательная регистрация)');
  let p = await boot(browser, { signedIn: false });
  assert.ok(await p.$eval('#login', (e) => e.classList.contains('open'))); assert.ok(!(await p.$eval('#loginBtn', (e) => e.hidden))); ok('без сессии показан экран входа');
  assert.ok((await calls(p, 'appReady')).length === 1); ok('интерфейс сообщает нативной заставке о готовности ровно один раз');
  await p.click('#loginBtn'); await p.waitForTimeout(150);
  assert.ok(!(await p.$eval('#login', (e) => e.classList.contains('open')))); ok('после входа Google экран входа закрывается');
  await emit(p, 'auth', { signedIn: false }); await p.waitForTimeout(50);
  assert.ok(await p.$eval('#login', (e) => e.classList.contains('open'))); ok('после выхода экран входа возвращается');
  await emit(p, 'auth', { signedIn: false, error: 'GetCredentialCancellationException: x' }); await p.waitForTimeout(50);
  assert.match(await p.$eval('#loginErr', (e) => e.textContent), /отменён/); ok('отмена входа даёт понятное сообщение');
  await p.close();
  p = await boot(browser, { signedIn: false, google: false });
  assert.ok(await p.$eval('#loginBtn', (e) => e.hidden)); assert.ok(!(await p.$eval('#loginGuest', (e) => e.hidden)));
  assert.match(await p.$eval('#loginText', (e) => e.textContent), /не настроен/); ok('без Web Client ID честно сказано, что вход не настроен (без тупика)');
  await p.close();

  console.log('Чат');
  p = await boot(browser, { signedIn: true });
  await p.fill('#input', 'Привет'); await p.click('#sendBtn'); await p.waitForTimeout(100);
  const userEl = await p.evaluateHandle(() => document.querySelector('.msg.user')); await p.evaluate((e) => { e.__mark = 1; }, userEl);
  const id1 = await p.evaluate(() => window.__lastReq);
  await emit(p, 'chatDelta', { id: id1, text: 'Первый абзац.\n\nВторой ' }); await p.waitForTimeout(150);
  await emit(p, 'chatDelta', { id: id1, text: 'абзац.' }); await p.waitForTimeout(150);
  await emit(p, 'chatDone', { id: id1 }); await p.waitForTimeout(150);
  assert.equal(await p.evaluate(() => document.querySelector('.msg.user').__mark), 1); ok('сообщения не пересоздаются при потоке и завершении (инкрементальный рендер)');
  assert.equal(await p.$$eval('.msg', (e) => e.length), 2); ok('нет дубликатов сообщений');
  assert.match(await p.$eval('.msg.assistant .md', (e) => e.textContent), /Первый абзац\.\s*Второй абзац\./); ok('потоковый ответ собран без потерь');
  // повторное завершение и «чужой» ответ не меняют чат
  await emit(p, 'chatDone', { id: id1 }); await emit(p, 'chatDelta', { id: 'ghost', text: 'ЧУЖОЙ' }); await p.waitForTimeout(100);
  assert.ok(!(await p.$eval('#messages', (e) => e.textContent.includes('ЧУЖОЙ')))); ok('запоздалый/чужой ответ игнорируется');
  // переключение чата во время генерации
  await p.fill('#input', 'Второй чат вопрос'); await p.click('#sendBtn'); await p.waitForTimeout(80);
  const id2 = await p.evaluate(() => window.__lastReq);
  await p.click('#topNew'); await p.waitForTimeout(80);
  await emit(p, 'chatDelta', { id: id2, text: 'ОТВЕТ-В-ПЕРВОМ-ЧАТЕ' }); await emit(p, 'chatDone', { id: id2 }); await p.waitForTimeout(150);
  assert.ok(!(await p.$eval('#messages', (e) => e.textContent.includes('ОТВЕТ-В-ПЕРВОМ-ЧАТЕ')))); ok('при переключении чата ответ не попадает в другой чат');
  await p.evaluate(() => document.querySelector('.chat-open').click()); await p.waitForTimeout(100);
  assert.ok(await p.$eval('#messages', (e) => e.textContent.includes('ОТВЕТ-В-ПЕРВОМ-ЧАТЕ'))); ok('ответ дошёл в чат, где был задан вопрос');
  // отмена генерации
  await p.fill('#input', 'ещё'); await p.click('#sendBtn'); await p.waitForTimeout(80);
  const id3 = await p.evaluate(() => window.__lastReq);
  await emit(p, 'chatDelta', { id: id3, text: 'частичный' }); await p.waitForTimeout(100);
  await p.click('#sendBtn'); await p.waitForTimeout(100);
  assert.equal((await calls(p, 'cancelChat')).pop()[1], id3); ok('отмена передаётся в Android (и далее на сервер)');
  await emit(p, 'chatDelta', { id: id3, text: ' ПОЗДНО' }); await p.waitForTimeout(100);
  assert.ok(!(await p.$eval('#messages', (e) => e.textContent.includes('ПОЗДНО')))); ok('после отмены поздние токены не добавляются');
  assert.match(await p.$eval('#messages', (e) => e.textContent), /Генерация остановлена/); ok('частичный ответ сохранён с пометкой');
  // XSS
  await p.fill('#input', 'xss'); await p.click('#sendBtn'); await p.waitForTimeout(80);
  const id4 = await p.evaluate(() => window.__lastReq);
  await emit(p, 'chatDelta', { id: id4, text: '<img src=x onerror=alert(1)> <script>window.__x=1</script> [a](javascript:alert(1)) [ok](https://example.com)' }); await emit(p, 'chatDone', { id: id4 }); await p.waitForTimeout(150);
  assert.equal(await p.$$eval('#messages img, #messages script', (e) => e.length), 0);
  assert.equal(await p.$$eval('#messages a[href^="javascript"]', (e) => e.length), 0); assert.equal(await p.evaluate(() => window.__x), undefined); ok('Markdown безопасен: HTML и javascript:-ссылки не выполняются');
  // ошибка сети
  await p.fill('#input', 'сеть'); await p.click('#sendBtn'); await p.waitForTimeout(80);
  const id5 = await p.evaluate(() => window.__lastReq);
  await emit(p, 'chatError', { id: id5, code: 'network', detail: '' }); await p.waitForTimeout(150);
  assert.match(await p.$eval('.msg.assistant.error', (e) => e.textContent), /Нет соединения/); ok('потеря сети: понятная ошибка, а не ложный успех');
  // длинное сообщение и 4 языка
  const long = ('Очень длинное слово ' + 'А'.repeat(300) + ' ').repeat(3) + ' Salam, necə kömək edə bilərsən? Merhaba, bugün nasılsın? Hello world.';
  await p.fill('#input', long); await p.click('#sendBtn'); await p.waitForTimeout(100);
  const over = await p.evaluate(() => { const s = document.querySelector('#scroller'); return s.scrollWidth > s.clientWidth + 1; });
  assert.ok(!over); ok('длинный текст не вызывает горизонтальной прокрутки');
  assert.deepEqual(await p.evaluate(() => ['Привет, как дела?', 'Salam, necə kömək edə bilərsən?', 'Merhaba, bugün nasılsın?', 'Hello, how can you help me?'].map((t) => detectLang(t))), ['ru', 'az', 'tr', 'en']); ok('определение 4 языков');
  await p.close();

  console.log('Сохранение');
  p = await boot(browser, { signedIn: true });
  await p.fill('#input', 'Запомнить это'); await p.click('#sendBtn'); await p.waitForTimeout(100);
  const idp = await p.evaluate(() => window.__lastReq); await emit(p, 'chatDelta', { id: idp, text: 'Сохранённый ответ' }); await emit(p, 'chatDone', { id: idp }); await p.waitForTimeout(500);
  const stored = await p.evaluate(() => localStorage.getItem('jarvis_chats_v2'));
  const ctx2 = p.context(); const p2 = await ctx2.newPage(); p2.errors = [];
  await p2.addInitScript(([s]) => { localStorage.setItem('jarvis_chats_v2', s); localStorage.setItem('jarvis_key_prompt_skipped', '1'); window.JarvisBridge = new Proxy({}, { get: (_, n) => () => (n === 'getState' ? JSON.stringify({ settings: { mode: 'own', provider: 'openrouter', model: 'm', lang: 'auto', voices: {}, systemPrompt: '' }, profile: { signedIn: true, email: 'a@b' }, configured: { backend: true, google: true } }) : n === 'hasKey' ? true : null) }); }, [stored]);
  await p2.goto(PAGE); await p2.waitForTimeout(250);
  await p2.evaluate(() => document.querySelector('.chat-open').click()); await p2.waitForTimeout(100);
  assert.ok(await p2.$eval('#messages', (e) => e.textContent.includes('Сохранённый ответ'))); ok('история восстанавливается после перезапуска');
  await p2.close(); await p.close();

  console.log('Сервер, сеть, объявления');
  p = await boot(browser, { signedIn: true });
  await emit(p, 'bootstrap', { serverChecked: true, serverOk: false, online: true, appConfig: '' }); await p.waitForTimeout(60);
  assert.ok(!(await p.$eval('#netPill', (e) => e.hidden))); assert.match(await p.$eval('#netPill', (e) => e.textContent), /недоступен/); ok('сервер недоступен: статус и кнопка повтора');
  await p.click('#netPill'); assert.equal((await calls(p, 'retryBootstrap')).length, 1); ok('повтор проверки сервера');
  await emit(p, 'bootstrap', { serverChecked: true, serverOk: true, online: false, appConfig: '' }); await p.waitForTimeout(60);
  assert.equal(await p.$eval('body', (e) => e.dataset.orb), 'offline'); ok('нет сети: шар в состоянии «нет соединения»');
  await emit(p, 'bootstrap', { serverChecked: true, serverOk: true, online: true, appConfig: JSON.stringify({ announcement: 'Работы до 12:00', maintenance: true, systemPrompt: 'Серверный промпт', features: { screenShare: false, onlineTts: false }, ttsAvailable: true }) }); await p.waitForTimeout(60);
  assert.equal(await p.$eval('#notice', (e) => e.textContent), 'Работы до 12:00'); ok('объявление администратора показывается');
  assert.ok(await p.$eval('[data-open="panelScreen"]', (e) => e.hidden)); ok('функция, выключенная админом, скрыта');
  assert.ok(await p.$eval('#ttsEngine option[value="online"]', (e) => e.disabled)); ok('нейро-голос недоступен, если выключен админом');
  await p.fill('#input', 'промпт'); await p.click('#sendBtn'); await p.waitForTimeout(100);
  const sent = JSON.parse((await calls(p, 'sendChat')).pop()[2]);
  assert.match(sent[0].content, /^Серверный промпт/); ok('серверный промпт по умолчанию применяется к запросам');
  await p.close();

  console.log('Голосовой режим и озвучка');
  p = await boot(browser, { signedIn: true });
  for (let i = 0; i < 5; i++) { await p.click('#openVoice'); await p.waitForTimeout(60); await p.click('#vEnd'); await p.waitForTimeout(60); }
  assert.equal(await p.$$eval('#voiceLangs .chip', (e) => e.length), 4); ok('многократное открытие/закрытие не дублирует элементы');
  assert.equal((await calls(p, 'stopSpeech')).length >= 5, true); ok('закрытие голосового режима останавливает речь');
  await p.click('#openVoice'); await p.waitForTimeout(100);
  const chip = await p.evaluateHandle(() => document.querySelector('#voiceLangs .chip')); await p.evaluate((e) => { e.__m = 1; }, chip);
  await emit(p, 'speech', { type: 'listening' }); await emit(p, 'speech', { type: 'level', level: 0.7 }); await emit(p, 'speech', { type: 'partial', text: 'привет' });
  await emit(p, 'tts', { state: 'speaking', msgId: 'x', index: 0, total: 2 }); await emit(p, 'ttsWord', {}); await emit(p, 'tts', { state: 'paused', msgId: 'x', index: 1, total: 2 }); await emit(p, 'tts', { state: 'speaking', msgId: 'x', index: 1, total: 2 }); await p.waitForTimeout(100);
  assert.equal(await p.evaluate(() => document.querySelector('#voiceLangs .chip').__m), 1); ok('события голоса не пересоздают экран');
  assert.equal(await p.$eval('body', (e) => e.dataset.orb), 'listening'); ok('шар отражает «слушаю»');
  await emit(p, 'speech', { type: 'error', code: 'permission_denied', permanent: true }); await p.waitForTimeout(60);
  assert.ok(!(await p.$eval('#vPerm', (e) => e.hidden))); assert.match(await p.$eval('#vState', (e) => e.textContent), /микрофон/i); ok('отказ в разрешении микрофона: понятное сообщение и кнопка настроек');
  assert.equal(await p.$eval('body', (e) => e.dataset.orb) === 'listening', false); ok('шар не показывает прослушивание без микрофона');
  await p.click('#vEnd'); await p.waitForTimeout(50); await p.close();

  console.log('Озвучивание в чате');
  p = await boot(browser, { signedIn: true });
  await p.fill('#input', 'озвучь'); await p.click('#sendBtn'); await p.waitForTimeout(80);
  const ids = await p.evaluate(() => window.__lastReq); await emit(p, 'chatDelta', { id: ids, text: 'Ответ для озвучки' }); await emit(p, 'chatDone', { id: ids }); await p.waitForTimeout(150);
  await p.click('.msg.assistant .act.spk'); assert.equal((await calls(p, 'speak')).length, 1); ok('кнопка динамика запускает озвучку');
  await emit(p, 'tts', { state: 'speaking', msgId: ids, index: 0, total: 1 }); await p.waitForTimeout(60);
  assert.equal(await p.$eval('.msg.assistant', (e) => e.dataset.tts), 'speaking'); ok('появляется пауза/стоп, динамик активен');
  await p.click('.msg.assistant .act.pz'); assert.equal((await calls(p, 'pauseSpeech')).length, 1);
  await emit(p, 'tts', { state: 'paused', msgId: ids, index: 0, total: 1 }); await p.waitForTimeout(60);
  assert.equal(await p.$eval('body', (e) => e.dataset.orb), 'paused'); ok('пауза: шар в состоянии паузы');
  await p.click('.msg.assistant .act.pl'); assert.equal((await calls(p, 'resumeSpeech')).length, 1); ok('продолжение речи');
  await p.click('.msg.assistant .act.st'); assert.equal((await calls(p, 'stopSpeech')).length >= 1, true); ok('остановка речи');
  await p.click('#sendBtn'); // повторные нажатия не создают дублей
  for (let i = 0; i < 4; i++) await p.click('#topNew', { force: true });
  assert.equal(await p.$$eval('#chatList .chat-item', (e) => e.length) >= 1, true); ok('повторные нажатия кнопок не ломают интерфейс');
  await p.close();

  console.log('Профиль и настройки');
  p = await boot(browser, { signedIn: true });
  await p.evaluate(() => document.querySelector('[data-open="panelVoice"]').click()); await p.waitForTimeout(300);
  await p.selectOption('#ttsEngine', 'online'); await p.waitForTimeout(80);
  assert.ok((await calls(p, 'saveSettings')).some((c) => JSON.parse(c[1]).ttsEngine === 'online')); ok('выбор движка голоса сохраняется');
  await p.evaluate(() => document.querySelector('.panel.open [data-close]').click()); await p.waitForTimeout(250);
  await p.evaluate(() => document.querySelector('[data-open="panelAccount"]').click()); await p.waitForTimeout(300);
  assert.ok(!(await p.$eval('#panelAccount', (e) => e.textContent.includes('Web Client ID')))); ok('технические поля (Client ID) скрыты от пользователя');
  await p.selectOption('#perfSel', 'lite'); await p.waitForTimeout(80);
  assert.ok(await p.$eval('body', (e) => e.classList.contains('lite'))); ok('лёгкий режим эффектов включается и сохраняется');
  assert.equal(p.errors.length, 0); ok('ошибок JavaScript нет');
  await p.close();

  await browser.close();
  console.log('\nПройдено проверок: ' + passed);
})().catch((e) => { console.error('ПРОВАЛ:', e.message); process.exit(1); });
