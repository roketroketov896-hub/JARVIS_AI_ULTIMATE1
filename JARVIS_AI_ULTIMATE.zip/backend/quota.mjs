// Чистая логика тарифов и лимитов (без сети и диска), чтобы её можно было тестировать.
export const DAY_MS = 86400000;

export function dayKey(ms) {
  return new Date(ms).toISOString().slice(0, 10); // сутки по UTC
}

export function nextResetMs(now) {
  const d = new Date(now);
  return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() + 1);
}

/** Активный тариф пользователя на момент now: 'free' | 'pro'. */
export function activePlan(user, now) {
  if (user.plan === 'pro' && (!user.planUntil || user.planUntil > now)) return 'pro';
  return 'free';
}

/**
 * user: { startedAt, dayKey, count, plan?, planUntil?, blocked?, dailyLimit? }
 * cfg: { unlimitedDays, dailyLimit, proDailyLimit }
 * Ничего не изменяет.
 */
export function evaluate(user, now, cfg) {
  const used = user.dayKey === dayKey(now) ? user.count : 0;
  if (user.blocked) {
    return { allowed: false, phase: 'blocked', plan: activePlan(user, now), usedToday: used, dailyLimit: 0, remainingToday: 0 };
  }
  if (activePlan(user, now) === 'pro') {
    const limit = Number.isFinite(user.dailyLimit) ? user.dailyLimit : cfg.proDailyLimit;
    return { allowed: used < limit, phase: 'pro', plan: 'pro', planUntil: user.planUntil || null, dailyLimit: limit,
      usedToday: used, remainingToday: Math.max(0, limit - used), resetAt: nextResetMs(now) };
  }
  const limit = Number.isFinite(user.dailyLimit) ? user.dailyLimit : cfg.dailyLimit;
  const unlimitedUntil = user.startedAt + cfg.unlimitedDays * DAY_MS;
  if (now < unlimitedUntil) {
    return { allowed: true, phase: 'unlimited', plan: 'free', unlimitedUntil, daysLeft: Math.ceil((unlimitedUntil - now) / DAY_MS),
      dailyLimit: limit, usedToday: used };
  }
  return { allowed: used < limit, phase: 'limited', plan: 'free', unlimitedUntil, daysLeft: 0, dailyLimit: limit,
    usedToday: used, remainingToday: Math.max(0, limit - used), resetAt: nextResetMs(now) };
}

/** Резервирует один запрос. Возвращает { ok, status }. Изменяет user. */
export function reserve(user, now, cfg) {
  const st = evaluate(user, now, cfg);
  if (!st.allowed) return { ok: false, status: st };
  if (user.dayKey !== dayKey(now)) { user.dayKey = dayKey(now); user.count = 0; }
  user.count += 1;
  user.total = (user.total || 0) + 1;
  user.lastSeen = now;
  return { ok: true, status: evaluate(user, now, cfg) };
}

/** Возвращает резерв, если запрос к провайдеру не удался. */
export function refund(user, now) {
  if (user.dayKey === dayKey(now) && user.count > 0) { user.count -= 1; if (user.total > 0) user.total -= 1; }
}
