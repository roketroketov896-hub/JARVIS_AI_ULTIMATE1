import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { verifyGoogleIdToken } from './auth.mjs';

const { publicKey, privateKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const jwk = { ...publicKey.export({ format: 'jwk' }), kid: 'k1', alg: 'RS256', use: 'sig' };
const getJwks = async () => ({ keys: [jwk] });
const enc = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
function make(payload, key = privateKey, kid = 'k1') {
  const h = enc({ alg: 'RS256', kid, typ: 'JWT' }), p = enc(payload);
  const sig = crypto.sign('RSA-SHA256', Buffer.from(h + '.' + p), key).toString('base64url');
  return h + '.' + p + '.' + sig;
}
const now = Date.now();
const good = { iss: 'https://accounts.google.com', aud: 'CID', sub: '123', email: 'a@b.c', email_verified: true, exp: Math.floor(now / 1000) + 600 };

const u = await verifyGoogleIdToken(make(good), { clientId: 'CID', getJwks, now });
assert.equal(u.sub, '123');
await assert.rejects(verifyGoogleIdToken(make({ ...good, aud: 'OTHER' }), { clientId: 'CID', getJwks, now }), /aud/);
await assert.rejects(verifyGoogleIdToken(make({ ...good, exp: Math.floor(now / 1000) - 5 }), { clientId: 'CID', getJwks, now }), /expired/);
await assert.rejects(verifyGoogleIdToken(make({ ...good, iss: 'https://evil.example' }), { clientId: 'CID', getJwks, now }), /iss/);
const other = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 }).privateKey;
await assert.rejects(verifyGoogleIdToken(make(good, other), { clientId: 'CID', getJwks, now }), /signature/);
await assert.rejects(verifyGoogleIdToken('abc', { clientId: 'CID', getJwks, now }), /malformed/);
console.log('auth tests passed');
