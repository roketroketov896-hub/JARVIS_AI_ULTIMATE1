import assert from 'node:assert/strict';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import fs from 'node:fs';
import { createApp, sealSecret, openSecret } from './server.mjs';

// поддельный провайдер ИИ: запоминает, с каким ключом и моделью к нему обратились
let upstreamFail = false; const seen = [];
const upstream = http.createServer((req, res) => {
  let b = ''; req.on('data', (c) => (b += c)); req.on('end', () => {
    if (req.url.startsWith('/auth/key')) { res.writeHead(req.headers.authorization === 'Bearer GOODKEY123456' ? 200 : 401); return res.end('{}'); }
    seen.push({ auth: req.headers.authorization, model: JSON.parse(b).model });
    if (upstreamFail) { res.writeHead(500); return res.end('x'); }
    res.writeHead(200, { 'Content-Type': 'text/event-stream' });
    res.write('data: {"choices":[{"delta":{"content":"Прив"}}]}\n\n');
    res.end('data: [DONE]\n\n');
  });
});
await new Promise((r) => upstream.listen(0, r));
const upBase = 'http://127.0.0.1:' + upstream.address().port;

let clock = Date.UTC(2026, 0, 1, 12);
const file = path.join(os.tmpdir(), 'jarvis-test-' + Date.now() + '.json');
const users = { tokA: { sub: 'A', email: 'a@x' }, tokB: { sub: 'B', email: 'b@x' }, tokAdmin: { sub: 'ADM', email: 'Boss@x', emailVerified: true }, tokFake: { sub: 'F', email: 'boss@x', emailVerified: false } };
const mk = () => createApp({ dataFile: file, upstreamUrl: upBase + '/v1/chat/completions', keyCheckUrl: upBase + '/auth/key', openrouterKey: 'ENVKEY-0000000000', freeModel: 'free-m', proModel: 'pro-m',
  adminEmails: ['boss@x'], configSecret: 'secret', azureKey: 'AZKEY', ttsUrl, ttsFreeChars: 50, ttsProChars: 500, ipLimitPerMin: 100000, now: () => clock, verify: async (t) => { if (users[t]) return users[t]; throw new Error('bad'); } });
// поддельный сервис синтеза речи
const ttsSeen = [];
const ttsUp = http.createServer((req, res) => { let b = ''; req.on('data', c => (b += c)); req.on('end', () => { ttsSeen.push({ key: req.headers['ocp-apim-subscription-key'], ssml: b }); res.writeHead(200, { 'Content-Type': 'audio/mpeg' }); res.end(Buffer.from([1, 2, 3, 4])); }); });
await new Promise((r) => ttsUp.listen(0, r));
const ttsUrl = 'http://127.0.0.1:' + ttsUp.address().port + '/tts';
const app = mk();
await new Promise((r) => app.server.listen(0, r));
const base = 'http://127.0.0.1:' + app.server.address().port;
const call = (p, tok, method = 'GET', body) => fetch(base + p, { method, headers: { ...(tok ? { Authorization: 'Bearer ' + tok } : {}), 'Content-Type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) });
const chat = (tok) => call('/v1/chat', tok, 'POST', { messages: [{ role: 'user', content: 'hi' }] });

assert.equal((await call('/health')).status, 200);
assert.equal((await call('/v1/status')).status, 401);

// обычный пользователь: безлимит 15 дней, потом 5 в день
for (let i = 0; i < 8; i++) assert.equal((await chat('tokA')).status, 200);
assert.equal(seen.at(-1).auth, 'Bearer ENVKEY-0000000000');
assert.equal(seen.at(-1).model, 'free-m');
clock += 15 * 86400000;
for (let i = 0; i < 5; i++) assert.equal((await chat('tokA')).status, 200);
const blocked = await chat('tokA');
assert.equal(blocked.status, 429);
assert.equal((await blocked.json()).error.code, 'daily_limit');

// админ-функции недоступны обычным и «непроверенным» почтам
assert.equal((await call('/admin/config', 'tokA')).status, 403);
assert.equal((await call('/admin/users', 'tokFake')).status, 403);
assert.equal((await call('/admin/config')).status, 401);
assert.equal((await call('/admin/me', 'tokAdmin')).status, 200);

// смена общего ключа и модели через админку, пользователи сразу используют новый ключ
let cfg = await (await call('/admin/config', 'tokAdmin')).json();
assert.equal(cfg.keySource, 'env');
assert.equal((await (await call('/admin/test-key', 'tokAdmin', 'POST', { openrouterKey: 'BAD-KEY-1234567890' })).json()).ok, false);
assert.equal((await (await call('/admin/test-key', 'tokAdmin', 'POST', { openrouterKey: 'GOODKEY123456' })).json()).ok, true);
cfg = await (await call('/admin/config', 'tokAdmin', 'PUT', { openrouterKey: 'GOODKEY123456', freeModel: 'free-m2', dailyLimit: 7 })).json();
assert.equal(cfg.keySource, 'admin'); assert.equal(cfg.keyHint, '…3456'); assert.equal(cfg.encryptedAtRest, true); assert.equal(cfg.dailyLimit, 7);
assert.ok(!JSON.stringify(cfg).includes('GOODKEY'), 'ключ не должен возвращаться');
await app.flush();
assert.ok(!fs.readFileSync(file, 'utf8').includes('GOODKEY'), 'ключ не должен лежать на диске открытым текстом');
clock += 86400000;
assert.equal((await chat('tokA')).status, 200);
assert.equal(seen.at(-1).auth, 'Bearer GOODKEY123456');
assert.equal(seen.at(-1).model, 'free-m2');

// управление пользователями: список, Pro, блокировка
let list = (await (await call('/admin/users?q=a@', 'tokAdmin')).json()).users;
assert.equal(list.length, 1); assert.equal(list[0].email, 'a@x');
const subA = list[0].sub;
let r = await call('/admin/users/' + subA, 'tokAdmin', 'PATCH', { plan: 'pro', days: 30 });
let pu = await r.json();
assert.equal(pu.plan, 'pro'); assert.equal(pu.status.dailyLimit, 200);
assert.equal((await chat('tokA')).status, 200);
assert.equal(seen.at(-1).model, 'pro-m');
pu = await (await call('/admin/users/' + subA, 'tokAdmin', 'PATCH', { blocked: true })).json();
assert.equal(pu.blocked, true);
const bl = await chat('tokA');
assert.equal(bl.status, 403); assert.equal((await bl.json()).error.code, 'blocked');
assert.equal((await (await call('/v1/status', 'tokA')).json()).phase, 'blocked');
await call('/admin/users/' + subA, 'tokAdmin', 'PATCH', { blocked: false, plan: 'free' });
assert.equal((await chat('tokA')).status, 200);
const ov = await fetch(base + '/admin/users/' + subA, { method: 'POST', headers: { Authorization: 'Bearer tokAdmin', 'X-HTTP-Method-Override': 'PATCH', 'Content-Type': 'application/json' }, body: JSON.stringify({ dailyLimit: 9 }) });
assert.equal((await ov.json()).dailyLimitOverride, 9);
await call('/admin/users/' + subA, 'tokAdmin', 'PATCH', { dailyLimit: null });
assert.equal((await call('/admin/users/nobody', 'tokAdmin', 'PATCH', { blocked: true })).status, 404);
assert.equal((await call('/admin/users/' + subA, 'tokA', 'PATCH', { plan: 'pro' })).status, 403);
const stats = await (await call('/admin/stats', 'tokAdmin')).json();
assert.ok(stats.users >= 1 && stats.totalRequests > 10);

// ошибка провайдера не списывает запрос; ключ без CONFIG_SECRET отсутствует => 503
upstreamFail = true;
const before = (await (await call('/v1/status', 'tokB')).json()).usedToday;
assert.equal((await chat('tokB')).status, 502);
upstreamFail = false;
assert.equal((await (await call('/v1/status', 'tokB')).json()).usedToday, before);

// нейро-голос: мужской голос по языку, лимит символов, блокировка, ключ не уходит клиенту
const tts1 = await call('/v1/tts', 'tokB', 'POST', { text: 'Привет & <мир>', lang: 'ru' });
assert.equal(tts1.status, 200); assert.equal(tts1.headers.get('content-type'), 'audio/mpeg');
assert.equal((await tts1.arrayBuffer()).byteLength, 4);
assert.equal(ttsSeen.at(-1).key, 'AZKEY'); assert.match(ttsSeen.at(-1).ssml, /ru-RU-DmitryNeural/); assert.match(ttsSeen.at(-1).ssml, /&amp; &lt;мир&gt;/);
for (const [l, v] of [['az', 'az-AZ-BabekNeural'], ['tr', 'tr-TR-AhmetNeural'], ['en', 'en-US-GuyNeural']]) { await call('/v1/tts', 'tokB', 'POST', { text: 'x', lang: l }); assert.match(ttsSeen.at(-1).ssml, new RegExp(v)); }
assert.equal((await call('/v1/tts', 'tokB', 'POST', { text: 'x'.repeat(60), lang: 'ru' })).status, 429);
assert.equal((await call('/v1/tts', 'tokB', 'POST', { text: 'x', lang: 'xx' })).status, 400);
assert.equal((await call('/v1/tts')).status, 401);
assert.equal((await (await call('/v1/status', 'tokB')).json()).ttsAvailable, true);

// отмена генерации клиентом прерывает запрос к провайдеру и возвращает резерв
const slow = http.createServer((req, res) => { res.writeHead(200, { 'Content-Type': 'text/event-stream' }); res.write('data: {"choices":[{"delta":{"content":"a"}}]}\n\n'); });
await new Promise((r) => slow.listen(0, r));
const appSlow = createApp({ dataFile: file + '.slow', upstreamUrl: 'http://127.0.0.1:' + slow.address().port + '/x', openrouterKey: 'k', freeModel: 'm', now: () => clock, verify: async () => ({ sub: 'S', email: 's@x' }) });
await new Promise((r) => appSlow.server.listen(0, r));
const ctl = new AbortController();
const rs = await fetch('http://127.0.0.1:' + appSlow.server.address().port + '/v1/chat', { method: 'POST', signal: ctl.signal, headers: { Authorization: 'Bearer t', 'Content-Type': 'application/json' }, body: JSON.stringify({ messages: [{ role: 'user', content: 'x' }] }) });
await rs.body.getReader().read(); ctl.abort(); await new Promise((r) => setTimeout(r, 200));
assert.equal(appSlow.db().users.S.count, 1, 'частично выданный ответ остаётся учтённым');
appSlow.server.close(); slow.close();

// параллельные запросы одного пользователя ограничены
const gate = http.createServer((req, res) => { setTimeout(() => { res.writeHead(200, { 'Content-Type': 'text/event-stream' }); res.end('data: {"choices":[{"delta":{"content":"a"}}]}\n\ndata: [DONE]\n\n'); }, 250); });
await new Promise((r) => gate.listen(0, r));
const appP = createApp({ dataFile: file + '.par', upstreamUrl: 'http://127.0.0.1:' + gate.address().port + '/x', openrouterKey: 'k', freeModel: 'm', maxParallelChats: 2, now: () => clock, verify: async () => ({ sub: 'P', email: 'p@x' }) });
await new Promise((r) => appP.server.listen(0, r));
const pc = () => fetch('http://127.0.0.1:' + appP.server.address().port + '/v1/chat', { method: 'POST', headers: { Authorization: 'Bearer t', 'Content-Type': 'application/json' }, body: JSON.stringify({ messages: [{ role: 'user', content: 'x' }] }) });
const codes = (await Promise.all([pc(), pc(), pc(), pc()])).map((r) => r.status).sort();
assert.deepEqual(codes, [200, 200, 429, 429]);
appP.server.close(); gate.close();

// ограничение запросов с одного IP
const appR = createApp({ dataFile: file + '.rl', openrouterKey: 'k', ipLimitPerMin: 5, now: () => clock, verify: async () => null });
await new Promise((r) => appR.server.listen(0, r));
const rc = []; for (let i = 0; i < 8; i++) rc.push((await fetch('http://127.0.0.1:' + appR.server.address().port + '/v1/status')).status);
assert.ok(rc.includes(429) && rc[0] === 401, 'rate limit: ' + rc.join(','));
appR.server.close();

// история и изоляция
assert.equal((await call('/v1/history', 'tokA', 'PUT', { chats: [{ id: '1', messages: [] }] })).status, 200);
assert.equal((await (await call('/v1/history', 'tokA')).json()).chats.length, 1);
assert.deepEqual((await (await call('/v1/history', 'tokB')).json()).chats, []);

// режим google: админ-маршруты закрыты без токена администратора
assert.equal((await call('/admin/config')).status, 401);
assert.equal((await (await call('/health')).json()).adminMode, 'google');

// перезапуск: ключ и настройки сохраняются
await app.flush();
app.server.close();
const app2 = mk();
assert.equal(app2.db().config.freeModel, 'free-m2');
assert.equal(openSecret(app2.db().config.keyStored, 'secret'), 'GOODKEY123456');
assert.equal(openSecret(app2.db().config.keyStored, 'wrong'), '');
assert.equal(sealSecret('x', ''), 'plain:x');


// ---------- режим админки без входа, настройки ИИ/голоса, журнал, диагностика ----------
const upBodies = [];
const spy = http.createServer((req, res) => { let b = ''; req.on('data', (c) => (b += c)); req.on('end', () => { upBodies.push(JSON.parse(b)); res.writeHead(200, { 'Content-Type': 'text/event-stream' }); res.end('data: {"choices":[{"delta":{"content":"ok"}}]}\n\ndata: [DONE]\n\n'); }); });
await new Promise((r) => spy.listen(0, r));
const appO = createApp({ dataFile: file + '.open', upstreamUrl: 'http://127.0.0.1:' + spy.address().port + '/x', openrouterKey: 'k', freeModel: 'fm', adminMode: 'open', azureKey: 'AZ', ttsUrl, ipLimitPerMin: 100000, now: () => clock,
  verify: async (t) => (t === 'u1' ? { sub: 'U1', email: 'u1@x' } : null) });
await new Promise((r) => appO.server.listen(0, r));
const bo = 'http://127.0.0.1:' + appO.server.address().port;
const open = (m, p, body) => fetch(bo + p, { method: m, headers: { 'Content-Type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) });
const asUser = (p, body) => fetch(bo + p, { method: 'POST', headers: { Authorization: 'Bearer u1', 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
assert.equal((await (await open('GET', '/health')).json()).adminMode, 'open');
assert.equal((await open('GET', '/admin/me')).status, 200, 'админка открывается без входа');
assert.equal((await fetch(bo + '/v1/status')).status, 401, 'обычные маршруты по-прежнему требуют вход');
assert.equal((await fetch(bo + '/v1/chat', { method: 'POST', body: '{}' })).status, 401);
await asUser('/v1/chat', { messages: [{ role: 'system', content: 'CLIENT' }, { role: 'user', content: 'hi' }] });
// системный промпт, температура и модель из админки реально доходят до провайдера
let c1 = await (await open('PUT', '/admin/config', { systemPrompt: 'ADMIN PROMPT', temperature: 0.3, topP: 0.9, maxTokens: 777, freeModel: 'new-model' })).json();
assert.equal(c1.systemPrompt, 'ADMIN PROMPT'); assert.equal(c1.temperature, 0.3);
await asUser('/v1/chat', { messages: [{ role: 'system', content: 'CLIENT' }, { role: 'user', content: 'hi' }] });
const ub = upBodies.at(-1);
assert.equal(ub.model, 'new-model'); assert.equal(ub.temperature, 0.3); assert.equal(ub.top_p, 0.9); assert.equal(ub.max_tokens, 777);
assert.match(ub.messages[0].content, /^ADMIN PROMPT\n\nCLIENT$/); assert.equal(ub.messages.length, 2);
// проверка значений
assert.equal((await open('PUT', '/admin/config', { temperature: 5 })).status, 400);
assert.equal((await open('PUT', '/admin/config', { voices: { ru: 'bad voice!' } })).status, 400);
assert.equal((await open('PUT', '/admin/config', { maxTokens: 'abc' })).status, 400);
// сброс параметра к значению по умолчанию
assert.equal((await (await open('PUT', '/admin/config', { temperature: null })).json()).temperature, null);
// публичная конфигурация для приложений
let ac = await (await fetch(bo + '/v1/app-config')).json();
assert.equal(ac.systemPrompt, 'ADMIN PROMPT'); assert.equal(ac.maintenance, false); assert.equal(ac.features.gmail, true);
await open('PUT', '/admin/config', { maintenance: true, announcement: 'Работы до 12:00', features: { gmail: false } });
ac = await (await fetch(bo + '/v1/app-config')).json();
assert.equal(ac.maintenance, true); assert.equal(ac.features.gmail, false);
const mt = await asUser('/v1/chat', { messages: [{ role: 'user', content: 'x' }] });
assert.equal(mt.status, 503); assert.equal((await mt.json()).error.code, 'maintenance');
await open('PUT', '/admin/config', { maintenance: false });
// голос: свой голос и скорость применяются
await open('PUT', '/admin/config', { voices: { ru: 'ru-RU-SvetlanaNeural' }, voiceRate: 5 });
await asUser('/v1/tts', { text: 'x', lang: 'ru' });
assert.match(ttsSeen.at(-1).ssml, /ru-RU-SvetlanaNeural/); assert.match(ttsSeen.at(-1).ssml, /rate='5%'/);
assert.equal((await (await open('POST', '/admin/test-tts', { lang: 'tr' })).json()).ok, true);
await open('PUT', '/admin/config', { ttsEnabled: false });
assert.equal((await asUser('/v1/tts', { text: 'x', lang: 'ru' })).status, 503);
// ключ Azure из админки, интеграции, диагностика, журнал
const ci = await (await open('PUT', '/admin/config', { azureKey: 'AZURE-KEY-123456789', azureRegion: 'westeurope', ttsEnabled: true })).json();
assert.equal(ci.azureSource, 'admin'); assert.ok(!JSON.stringify(ci).includes('AZURE-KEY'));
const integ = (await (await open('GET', '/admin/integrations')).json()).integrations;
assert.deepEqual(integ.map((i) => i.id), ['ai', 'tts', 'google', 'gmail']);
const dg = await (await open('GET', '/admin/diagnostics')).json();
assert.equal(dg.adminMode, 'open'); assert.equal(dg.users, 1); assert.ok(dg.uptimeSec >= 0);
const lg = (await (await open('GET', '/admin/logs')).json()).logs;
assert.ok(lg.some((l) => l.type === 'admin' && /systemPrompt/.test(l.message)), 'действия админа попадают в журнал');
assert.ok(!JSON.stringify(lg).includes('AZURE-KEY') && !JSON.stringify(lg).includes('ADMIN PROMPT'), 'в журнале нет ключей и текстов');
// пользователь: сброс счётчика и удаление истории
await asUser('/v1/chat', { messages: [{ role: 'user', content: 'x' }] });
await fetch(bo + '/v1/history', { method: 'PUT', headers: { Authorization: 'Bearer u1', 'Content-Type': 'application/json' }, body: JSON.stringify({ chats: [{ id: '1', messages: [] }] }) });
const u1 = (await (await open('GET', '/admin/users')).json()).users[0];
assert.equal(u1.hasHistory, true);
const pr = await (await open('PATCH', '/admin/users/' + u1.sub, { resetToday: true, deleteHistory: true })).json();
assert.equal(pr.status.usedToday, 0); assert.equal(pr.hasHistory, false);
assert.equal((await open('DELETE', '/admin/logs')).status, 200);
appO.server.close(); spy.close();


upstream.close(); ttsUp.close();
console.log('server tests passed');
process.exit(0);
