import assert from 'node:assert/strict';
import { evaluate, reserve, refund, DAY_MS, dayKey } from './quota.mjs';

const cfg = { unlimitedDays: 15, dailyLimit: 5, proDailyLimit: 200 };
const t0 = Date.UTC(2026, 0, 1, 10, 0, 0);
const fresh = () => ({ startedAt: t0, dayKey: '', count: 0 });

// первые 15 дней: нет дневного лимита JARVIS
const user = fresh();
for (let i = 0; i < 50; i++) assert.equal(reserve(user, t0 + 3 * DAY_MS, cfg).ok, true);
assert.equal(evaluate(user, t0 + 3 * DAY_MS, cfg).phase, 'unlimited');
assert.equal(evaluate(user, t0 + 3 * DAY_MS, cfg).daysLeft, 12);
const after = t0 + 15 * DAY_MS;
assert.equal(evaluate(user, after - 1, cfg).phase, 'unlimited');
assert.equal(evaluate(user, after, cfg).phase, 'limited');

// после 15 дней: 5 в день
const u2 = fresh();
for (let i = 0; i < 5; i++) assert.equal(reserve(u2, after + i, cfg).ok, true);
assert.equal(reserve(u2, after + 10, cfg).ok, false);
refund(u2, after + 20);
assert.equal(reserve(u2, after + 30, cfg).ok, true);
assert.equal(reserve(u2, after + 40, cfg).ok, false);
const nextDay = Date.UTC(2026, 0, 17, 0, 0, 1);
assert.notEqual(dayKey(after), dayKey(nextDay));
assert.equal(reserve(u2, nextDay, cfg).ok, true);

// блокировка
const b = { ...fresh(), blocked: true };
assert.equal(evaluate(b, t0, cfg).phase, 'blocked');
assert.equal(reserve(b, t0, cfg).ok, false);

// Pro: свой лимит, без 15-дневного окна, срок действия
const pro = { ...fresh(), plan: 'pro', planUntil: after + 10 * DAY_MS };
assert.equal(evaluate(pro, after, cfg).phase, 'pro');
assert.equal(evaluate(pro, after, cfg).dailyLimit, 200);
for (let i = 0; i < 200; i++) assert.equal(reserve(pro, after, cfg).ok, true);
assert.equal(reserve(pro, after, cfg).ok, false);
// Pro закончился -> снова free (15 дней уже прошли, лимит 5)
const expired = evaluate(pro, after + 11 * DAY_MS, cfg);
assert.equal(expired.plan, 'free');
assert.equal(expired.phase, 'limited');
// индивидуальный лимит
const custom = { ...fresh(), plan: 'pro', dailyLimit: 3 };
for (let i = 0; i < 3; i++) assert.equal(reserve(custom, after, cfg).ok, true);
assert.equal(reserve(custom, after, cfg).ok, false);
// бессрочный Pro
assert.equal(evaluate({ ...fresh(), plan: 'pro' }, after + 999 * DAY_MS, cfg).phase, 'pro');

console.log('quota tests passed');
