package com.jarvis.admin;

import org.json.JSONObject;

/** Канал событий из Java в JavaScript (WebView). */
interface Emitter {
    void emit(String event, JSONObject data);
}
