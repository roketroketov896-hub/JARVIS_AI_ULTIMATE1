package com.jarvis.admin;

import android.webkit.JavascriptInterface;

import org.json.JSONObject;

/**
 * Мост JavaScript → Android для админ-панели.
 * Права доступа к данным определяет сервер (ADMIN_MODE). Здесь нет паролей и ключей:
 * сохраняется только адрес сервера, который вводит сам администратор.
 */
final class AdminBridge {
    private final MainActivity act;

    AdminBridge(MainActivity act) {
        this.act = act;
    }

    private static JSONObject obj(Object... kv) {
        JSONObject o = new JSONObject();
        try {
            for (int i = 0; i + 1 < kv.length; i += 2) o.put(String.valueOf(kv[i]), kv[i + 1]);
        } catch (Exception ignored) {
        }
        return o;
    }

    static String normalizeBase(String url) {
        String u = url == null ? "" : url.trim();
        while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        return u.startsWith("https://") ? u : "";
    }

    private String base() {
        String saved = act.prefs.getString("backendUrl", "");
        String b = normalizeBase(saved);
        return b.isEmpty() ? normalizeBase(BuildConfig.BACKEND_URL) : b;
    }

    @JavascriptInterface
    public String getState() {
        return obj("backendUrl", base()).toString();
    }

    /** Возвращает true, если адрес принят (должен начинаться с https://). */
    @JavascriptInterface
    public boolean saveServer(String url) {
        String b = normalizeBase(url);
        if (b.isEmpty()) return false;
        act.prefs.edit().putString("backendUrl", b).apply();
        return true;
    }

    @JavascriptInterface
    public void clearServer() {
        act.prefs.edit().remove("backendUrl").apply();
    }

    /** Запрос к серверу JARVIS. Ответ приходит событием "api". */
    @JavascriptInterface
    public void api(final String reqId, final String method, final String path, final String body) {
        act.executor.execute(new Runnable() {
            @Override
            public void run() {
                JSONObject out;
                try {
                    String base = base();
                    if (base.isEmpty()) {
                        out = obj("reqId", reqId, "ok", false, "status", 0, "code", "not_configured", "body", "");
                    } else {
                        // Заголовок Authorization не отправляется: текущий этап админки без входа.
                        Http.Result r = Http.request(method, base + path, null, body);
                        out = obj("reqId", reqId, "ok", r.status >= 200 && r.status < 300, "status", r.status, "code", "", "body", r.body);
                    }
                } catch (Exception e) {
                    out = obj("reqId", reqId, "ok", false, "status", 0, "code", "network", "body", "");
                }
                act.emit("api", out);
            }
        });
    }
}
