'use strict';
(function () {
  const $ = (s, r) => (r || document).querySelector(s);
  const B = window.AdminBridge || null;
  function native(name) {
    const a = Array.prototype.slice.call(arguments, 1);
    try { if (B && typeof B[name] === 'function') return B[name].apply(B, a); } catch (e) { console.error(name, e); }
    return null;
  }
  const safeJson = (s, fb) => { try { const v = JSON.parse(s); return v == null ? fb : v; } catch (e) { return fb; } };
  const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

  const ICONS = {
    users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0M16 4.5a3.5 3.5 0 0 1 0 7M18 14a6.5 6.5 0 0 1 3.5 6"/>',
    gauge: '<path d="M4 18a8 8 0 1 1 16 0M12 18l4-6"/>',
    brain: '<path d="M9 4a3 3 0 0 0-3 3 3 3 0 0 0-2 5 3 3 0 0 0 2 5 3 3 0 0 0 6 1V4a3 3 0 0 0-3 0zM15 4a3 3 0 0 1 3 3 3 3 0 0 1 2 5 3 3 0 0 1-2 5 3 3 0 0 1-6 1"/>',
    plug: '<path d="M9 3v5M15 3v5M6 8h12v4a6 6 0 0 1-12 0zM12 18v3"/>',
    wave: '<path d="M3 12h2M7 8v8M11 4v16M15 8v8M19 10v4"/>',
    sliders: '<path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>',
    list: '<path d="M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01"/>',
    server: '<rect x="3" y="4" width="18" height="6" rx="2"/><rect x="3" y="14" width="18" height="6" rx="2"/><path d="M7 7h.01M7 17h.01"/>',
    back: '<path d="M15 6l-6 6 6 6"/>'
  };
  const ic = (n, s) => '<svg class="ic" width="' + (s || 24) + '" height="' + (s || 24) + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' + ICONS[n] + '</svg>';

  const S = { host: '', connected: false, adminMode: '', page: 'home', cfg: null, authIssue: false };
  const PAGES = {
    users: ['Пользователи', 'users', 'Аккаунты, блокировка, тарифы'],
    limits: ['Лимиты', 'gauge', 'Запросы, бесплатный период'],
    ai: ['Искусственный интеллект', 'brain', 'Модель, промпт, параметры, ключ'],
    integrations: ['API и интеграции', 'plug', 'Подключения и статусы'],
    voice: ['Голос', 'wave', 'Нейро-голос и языки'],
    appsettings: ['Настройки JARVIS', 'sliders', 'Объявление, режим работ, функции'],
    logs: ['Журналы и диагностика', 'list', 'События, ошибки, состояние'],
    system: ['Система', 'server', 'Сервер, режим доступа']
  };

  /* ---------- общие помощники ---------- */
  let toastTimer = 0;
  function toast(t) { const el = $('#toast'); el.textContent = t; el.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('show'), 3000); }
  function ask(text, yes) {
    return new Promise(res => {
      $('#dialogText').textContent = text; $('#dialogYes').textContent = yes || 'Подтвердить'; $('#dialog').hidden = false;
      const done = v => { $('#dialog').hidden = true; $('#dialogYes').onclick = null; $('#dialogNo').onclick = null; res(v); };
      $('#dialogYes').onclick = () => done(true); $('#dialogNo').onclick = () => done(false);
    });
  }
  const pending = {};
  function api(method, path, body) {
    return new Promise(resolve => {
      const id = uid();
      const timer = setTimeout(() => { delete pending[id]; resolve({ ok: false, status: 0, code: 'timeout', data: null }); }, 70000);
      pending[id] = r => { clearTimeout(timer); resolve(r); };
      if (!B) { clearTimeout(timer); delete pending[id]; resolve({ ok: false, status: 0, code: 'no_bridge', data: null }); return; }
      native('api', id, method, path, body === undefined ? '' : JSON.stringify(body));
    });
  }
  function errText(r) {
    if (r.code === 'not_configured') return 'Сервер не подключён. Открой «Система» и укажи адрес сервера.';
    if (r.code === 'network') return 'Нет связи с сервером.';
    if (r.code === 'timeout') return 'Сервер не ответил вовремя.';
    if (r.status === 401 || r.status === 403) return 'Сервер не разрешает доступ без входа. На сервере включи ADMIN_MODE=open (см. инструкцию).';
    const m = r.data && r.data.error && r.data.error.message;
    return m || ('Ошибка сервера' + (r.status ? ' (' + r.status + ')' : ''));
  }
  async function guarded(btn, fn) { if (btn.disabled) return; btn.disabled = true; try { return await fn(); } finally { btn.disabled = false; } }
  const view = html => { $('#view').innerHTML = html; $('#view').scrollTop = 0; };
  const row = (label, input, hint) => '<label>' + label + '</label>' + input + (hint ? '<div class="hint">' + hint + '</div>' : '');
  const num = (id, v, ph) => '<input id="' + id + '" class="field" type="number" inputmode="decimal" step="any" value="' + esc(v == null ? '' : v) + '" placeholder="' + esc(ph || '') + '">';
  const txt = (id, v, ph) => '<input id="' + id + '" class="field" value="' + esc(v == null ? '' : v) + '" placeholder="' + esc(ph || '') + '" autocomplete="off" autocapitalize="off">';
  const sw = (id, label, on) => '<label class="switch-row"><span>' + label + '</span><input type="checkbox" id="' + id + '"' + (on ? ' checked' : '') + '><i class="switch"></i></label>';
  const out = id => '<div class="note" id="' + id + '"></div>';
  function say(id, ok, t) { const e = $('#' + id); if (e) { e.className = 'note ' + (ok ? 'ok' : 'bad'); e.textContent = t; } }
  const val = id => $('#' + id).value.trim();
  const optNum = id => (val(id) === '' ? null : Number(val(id)));

  /* ---------- подключение к серверу ---------- */
  function setConn(state, text) { const c = $('#conn'); c.innerHTML = '<span class="dot ' + (state || '') + '"></span>' + esc(text); }
  async function connect(silent) {
    S.connected = false; S.authIssue = false;
    if (!S.host) { setConn('', 'нет сервера'); return false; }
    setConn('', 'проверка…');
    const h = await api('GET', '/health');
    if (!h.ok) { setConn('bad', 'сервер недоступен'); if (!silent) toast(errText(h)); return false; }
    S.adminMode = h.data && h.data.adminMode || '';
    const me = await api('GET', '/admin/me');
    if (me.ok) { S.connected = true; setConn('ok', 'подключено'); return true; }
    S.authIssue = me.status === 401 || me.status === 403;
    setConn('bad', S.authIssue ? 'доступ закрыт' : 'ошибка');
    return false;
  }

  /* ---------- главный экран ---------- */
  function showHome() {
    S.page = 'home'; $('#back').hidden = true; $('#title').textContent = 'Админ-панель';
    let banner = '';
    if (!S.host) banner = '<div class="banner warn glass"><b>Сервер не подключён</b><div class="note">Панель открыта, но управлять можно только через сервер JARVIS. Укажи его адрес в разделе «Система».</div><div class="row"><button class="btn primary" data-go="system">Подключить сервер</button></div></div>';
    else if (S.authIssue) banner = '<div class="banner bad glass"><b>Сервер закрывает админ-доступ</b><div class="note">Сервер работает в режиме с проверкой входа, а в этой версии панели входа нет. На сервере временно задай ADMIN_MODE=open (см. инструкцию), затем нажми «Повторить».</div><div class="row"><button class="btn primary" id="retry">Повторить</button></div></div>';
    else if (!S.connected) banner = '<div class="banner bad glass"><b>Нет связи с сервером</b><div class="note">' + esc(S.host) + '</div><div class="row"><button class="btn primary" id="retry">Повторить</button><button class="btn ghost" data-go="system">Система</button></div></div>';
    else if (S.adminMode === 'open') banner = '<div class="banner warn glass"><b>Админ-API открыт без входа</b><div class="note">Любой, кто знает адрес сервера, может управлять им. Это допустимо только на этапе настройки; потом включи защиту (ADMIN_MODE=google).</div></div>';
    const tiles = Object.keys(PAGES).map(k => '<button class="tile glass" data-go="' + k + '">' + ic(PAGES[k][1]) + '<b>' + PAGES[k][0] + '</b><small>' + PAGES[k][2] + '</small></button>').join('');
    view(banner + '<div class="tiles">' + tiles + '</div>');
    bindNav();
    const r = $('#retry'); if (r) r.onclick = async () => { await connect(false); showHome(); };
  }
  function bindNav() { document.querySelectorAll('[data-go]').forEach(b => { b.onclick = () => go(b.dataset.go); }); }
  async function go(page) {
    S.page = page; $('#back').hidden = false; $('#title').textContent = PAGES[page][0];
    if (page !== 'system' && !S.connected) {
      view('<div class="banner bad glass"><b>Нет подключения к серверу</b><div class="note">' + esc(S.host ? 'Сервер не отвечает или закрыл админ-доступ.' : 'Адрес сервера не указан.') + '</div><div class="row"><button class="btn primary" data-go="system">Открыть «Система»</button><button class="btn ghost" id="retry">Повторить</button></div></div>');
      bindNav(); $('#retry').onclick = async () => { if (await connect(false)) go(page); else go(page); };
      return;
    }
    view('<div class="note">Загрузка…</div>');
    await PAGE_FN[page]();
  }

  /* ---------- Пользователи ---------- */
  let searchTimer = 0, userReq = 0;
  async function pageUsers() {
    view('<label class="search"><input id="q" type="search" placeholder="Поиск по e-mail" autocomplete="off"></label><div class="note" id="meta"></div><div class="ulist" id="ulist"></div>');
    $('#q').oninput = () => { clearTimeout(searchTimer); searchTimer = setTimeout(loadUsers, 350); };
    await loadUsers();
  }
  async function loadUsers() {
    const my = ++userReq; const q = $('#q').value.trim();
    const r = await api('GET', '/admin/users' + (q ? '?q=' + encodeURIComponent(q) : ''));
    if (my !== userReq || S.page !== 'users') return;
    if (!r.ok) { $('#meta').textContent = errText(r); return; }
    const list = (r.data && r.data.users) || [];
    $('#meta').textContent = list.length ? 'Найдено: ' + list.length : 'Пользователей пока нет';
    const box = $('#ulist'); box.innerHTML = '';
    list.forEach(u => box.appendChild(userCard(u)));
  }
  function badges(u) {
    return (u.blocked ? '<span class="badge bad">заблокирован</span>' : '') + (u.plan === 'pro' ? '<span class="badge pro">Pro' + (u.planUntil ? ' до ' + esc(new Date(u.planUntil).toLocaleDateString()) : '') + '</span>' : '<span class="badge">Free</span>');
  }
  function usage(u) {
    const st = u.status || {};
    const t = st.phase === 'unlimited' ? 'сегодня ' + st.usedToday + ' (безлимитный период)' : 'сегодня ' + (st.usedToday || 0) + ' из ' + (st.dailyLimit == null ? '–' : st.dailyLimit);
    return t + (u.dailyLimitOverride != null ? ' (свой лимит ' + u.dailyLimitOverride + ')' : '') + ' · всего ' + (u.total || 0) + ' · голос сегодня ' + (u.ttsCharsToday || 0) + ' симв.';
  }
  function userCard(u) {
    const card = document.createElement('div'); card.className = 'ucard glass';
    card.innerHTML = '<button class="uhead"><b></b><div class="bd"></div><small></small></button><div class="uact">' +
      '<div class="note">Тариф</div><div class="row"><button class="btn primary" data-a="pro30">Pro 30 дн.</button><button class="btn primary" data-a="pro365">Pro 365 дн.</button><button class="btn ghost" data-a="proinf">Pro без срока</button><button class="btn ghost" data-a="free">Снять Pro</button></div>' +
      '<div class="note">Доступ</div><div class="row"><button class="btn danger" data-a="block"></button></div>' +
      '<div class="note">Свой лимит запросов в день</div><div class="row"><input class="field num" type="number" min="0" inputmode="numeric" placeholder="число"><button class="btn ghost" data-a="limit">Применить</button><button class="btn ghost" data-a="limitreset">Сбросить</button></div>' +
      '<div class="note">Данные</div><div class="row"><button class="btn ghost" data-a="resettoday">Обнулить счётчик дня</button><button class="btn danger" data-a="delhist">Удалить историю на сервере</button></div>' +
      '<div class="note dim sub"></div></div>';
    fill(card, u);
    $('.uhead', card).onclick = () => card.classList.toggle('open');
    card.addEventListener('click', e => { const b = e.target.closest('[data-a]'); if (b) guarded(b, () => userAction(card, b.dataset.a)); });
    return card;
  }
  function fill(card, u) {
    card.dataset.json = JSON.stringify(u);
    $('.uhead b', card).textContent = u.email || u.sub; $('.bd', card).innerHTML = badges(u); $('.uhead small', card).textContent = usage(u);
    $('[data-a="block"]', card).textContent = u.blocked ? 'Разблокировать' : 'Заблокировать';
    $('.sub', card).textContent = 'ID: ' + u.sub + ' · с ' + new Date(u.startedAt).toLocaleDateString() + (u.lastSeen ? ' · был ' + new Date(u.lastSeen).toLocaleString() : '') + (u.hasHistory ? ' · есть история на сервере' : '');
  }
  async function userAction(card, a) {
    const u = safeJson(card.dataset.json, null); if (!u) return; const who = u.email || u.sub; let body = null;
    if (a === 'pro30') body = { plan: 'pro', days: 30 }; else if (a === 'pro365') body = { plan: 'pro', days: 365 }; else if (a === 'proinf') body = { plan: 'pro' };
    else if (a === 'free') { if (!(await ask('Снять JARVIS Pro у ' + who + '?', 'Снять'))) return; body = { plan: 'free' }; }
    else if (a === 'block') { const next = !u.blocked; if (!(await ask((next ? 'Заблокировать ' : 'Разблокировать ') + who + '?', next ? 'Заблокировать' : 'Разблокировать'))) return; body = { blocked: next }; }
    else if (a === 'limit') { const v = $('.num', card).value; if (v === '' || Number(v) < 0) { toast('Введи число от 0'); return; } body = { dailyLimit: Number(v) }; }
    else if (a === 'limitreset') body = { dailyLimit: null };
    else if (a === 'resettoday') body = { resetToday: true };
    else if (a === 'delhist') { if (!(await ask('Удалить историю чатов ' + who + ' на сервере? Это необратимо.', 'Удалить'))) return; body = { deleteHistory: true }; }
    if (!body) return;
    const r = await api('PATCH', '/admin/users/' + encodeURIComponent(u.sub), body);
    if (!r.ok) { toast(errText(r)); return; }
    fill(card, r.data); toast('Готово: ' + who);
  }

  /* ---------- Лимиты ---------- */
  async function loadCfg() { const r = await api('GET', '/admin/config'); if (!r.ok) { view('<div class="banner bad glass"><b>Не удалось загрузить настройки</b><div class="note">' + esc(errText(r)) + '</div></div>'); return null; } S.cfg = r.data; return r.data; }
  async function save(body, outId, okText) {
    const r = await api('PUT', '/admin/config', body);
    if (!r.ok) { say(outId, false, errText(r)); return false; }
    S.cfg = r.data; say(outId, true, okText || 'Сохранено и применено на сервере.'); return true;
  }
  async function pageLimits() {
    const c = await loadCfg(); if (!c) return;
    view('<div class="card glass"><h3>Запросы к ИИ</h3>' +
      row('Дней без дневного лимита (с первого обращения)', num('unlimitedDays', c.unlimitedDays)) + row('Запросов в день после этого (Free)', num('dailyLimit', c.dailyLimit)) + row('Запросов в день для JARVIS Pro', num('proDailyLimit', c.proDailyLimit), 'Личный лимит пользователя из раздела «Пользователи» важнее этих значений. Сутки считаются по UTC.') +
      '</div><div class="card glass"><h3>Нейро-голос (символов в день)</h3>' + row('Free', num('ttsFreeChars', c.ttsFreeChars)) + row('Pro', num('ttsProChars', c.ttsProChars)) +
      '<div class="row"><button class="btn primary" id="save">Сохранить</button></div>' + out('o') + '</div>');
    $('#save').onclick = function () { guarded(this, async () => {
      const b = { unlimitedDays: optNum('unlimitedDays'), dailyLimit: optNum('dailyLimit'), proDailyLimit: optNum('proDailyLimit'), ttsFreeChars: optNum('ttsFreeChars'), ttsProChars: optNum('ttsProChars') };
      for (const k in b) if (b[k] == null || b[k] < 0) { say('o', false, 'Заполни все поля неотрицательными числами.'); return; }
      await save(b, 'o');
    }); };
  }

  /* ---------- Искусственный интеллект ---------- */
  async function pageAi() {
    const c = await loadCfg(); if (!c) return;
    view('<div class="card glass"><h3>Общий ключ ИИ</h3><div class="note ' + (c.hasKey ? 'ok' : 'bad') + '">' + (c.hasKey ? 'Ключ задан (' + esc(c.keyHint) + '), источник: ' + (c.keySource === 'admin' ? 'панель' : 'переменная сервера') + (c.keySource === 'admin' ? (c.encryptedAtRest ? ', зашифрован на диске' : ', НЕ зашифрован на диске (задай CONFIG_SECRET)') : '') : 'Ключ не задан: бесплатный режим не работает.') + '</div>' +
      row('Новый ключ OpenRouter', '<input id="newKey" class="field" type="password" placeholder="Вставь новый ключ" autocomplete="off" autocapitalize="off">') +
      '<div class="row"><button class="btn ghost" id="testKey">Проверить</button><button class="btn primary" id="saveKey">Сохранить для всех</button><button class="btn danger" id="clearKey">Удалить</button></div>' + out('ko') +
      '<div class="note dim">Ключ хранится на сервере и не показывается повторно. Новый ключ сразу действует во всех приложениях без пересборки. Личные ключи пользователей не затрагиваются.</div></div>' +
      '<div class="card glass"><h3>Модель и поведение</h3>' + row('Модель для Free', txt('freeModel', c.freeModel)) + row('Модель для Pro', txt('proModel', c.proModel)) +
      row('Системные инструкции JARVIS (для бесплатного режима и значение по умолчанию для приложений)', '<textarea id="sysPrompt" class="field area" placeholder="Пусто: используются инструкции приложения">' + esc(c.systemPrompt) + '</textarea>', 'Серверный промпт ставится первым; инструкции приложения (язык, формат) добавляются после него.') +
      row('Температура (0–2, пусто = по умолчанию провайдера)', num('temperature', c.temperature)) + row('top_p (0–1, пусто = по умолчанию)', num('topP', c.topP)) + row('Максимум токенов ответа', num('maxTokens', c.maxTokens)) +
      '<div class="row"><button class="btn primary" id="saveAi">Сохранить</button></div>' + out('ao') + '<div class="note dim">Названия моделей проверяет провайдер: если модели нет, запрос вернёт ошибку. Список моделей смотри на сайте провайдера.</div></div>');
    $('#testKey').onclick = function () { guarded(this, async () => { const k = val('newKey'); say('ko', true, 'Проверяю…'); const r = await api('POST', '/admin/test-key', k ? { openrouterKey: k } : {}); if (!r.ok) say('ko', false, errText(r)); else say('ko', !!r.data.ok, r.data.message); }); };
    $('#saveKey').onclick = function () { guarded(this, async () => { const k = val('newKey'); if (!k) { say('ko', false, 'Вставь ключ в поле.'); return; } if (!(await ask('Заменить общий ключ ИИ? Он сразу начнёт использоваться во всех приложениях.', 'Заменить'))) return; if (await save({ openrouterKey: k }, 'ko', 'Ключ применён для всех пользователей.')) pageAi(); }); };
    $('#clearKey').onclick = function () { guarded(this, async () => { if (!(await ask('Удалить ключ, заданный через панель? Если на сервере нет резервного ключа, бесплатный режим перестанет работать.', 'Удалить'))) return; if (await save({ clearKey: true }, 'ko', 'Ключ удалён.')) pageAi(); }); };
    $('#saveAi').onclick = function () { guarded(this, async () => {
      await save({ freeModel: val('freeModel'), proModel: val('proModel'), systemPrompt: $('#sysPrompt').value, temperature: optNum('temperature'), topP: optNum('topP'), maxTokens: optNum('maxTokens') }, 'ao');
    }); };
  }

  /* ---------- API и интеграции ---------- */
  async function pageIntegrations() {
    const [ir, c] = await Promise.all([api('GET', '/admin/integrations'), loadCfg()]); if (!c) return;
    const list = (ir.ok && ir.data.integrations) || [];
    const st = i => i.configured === true ? '<span class="badge pro">работает</span>' : i.configured === false ? '<span class="badge bad">не настроено</span>' : '<span class="badge">на устройстве</span>';
    view('<div class="card glass"><h3>Статусы</h3>' + list.map(i => '<div class="logrow"><b>' + esc(i.name) + '</b> ' + st(i) + '<small>' + esc(i.note || '') + (i.hint ? ' · ключ ' + esc(i.hint) : '') + (i.source && i.source !== 'device' ? ' · источник: ' + esc(i.source) : '') + '</small></div>').join('') +
      '<div class="row"><button class="btn ghost" data-go="ai">Ключ ИИ…</button></div></div>' +
      '<div class="card glass"><h3>Нейро-голос (Azure Speech)</h3>' + row('Регион сервиса (например westeurope)', txt('region', c.azureRegion)) +
      row('Ключ сервиса речи', '<input id="azKey" class="field" type="password" placeholder="' + (c.hasAzureKey ? 'Задан (' + esc(c.azureKeyHint) + '), введи новый для замены' : 'Вставь ключ') + '" autocomplete="off" autocapitalize="off">') +
      '<div class="row"><button class="btn primary" id="saveAz">Сохранить</button><button class="btn ghost" id="testAz">Проверить синтез</button><button class="btn danger" id="clearAz">Удалить ключ</button></div>' + out('io') + '</div>');
    bindNav();
    $('#saveAz').onclick = function () { guarded(this, async () => { const b = { azureRegion: val('region') }; if (val('azKey')) b.azureKey = val('azKey'); if (await save(b, 'io')) pageIntegrations(); }); };
    $('#clearAz').onclick = function () { guarded(this, async () => { if (!(await ask('Удалить ключ сервиса речи?', 'Удалить'))) return; if (await save({ clearAzureKey: true }, 'io', 'Ключ удалён.')) pageIntegrations(); }); };
    $('#testAz').onclick = function () { guarded(this, async () => { say('io', true, 'Проверяю…'); const r = await api('POST', '/admin/test-tts', { lang: 'ru' }); if (!r.ok) say('io', false, errText(r)); else say('io', !!r.data.ok, r.data.message); }); };
  }

  /* ---------- Голос ---------- */
  async function pageVoice() {
    const c = await loadCfg(); if (!c) return;
    const L = [['ru', 'Русский'], ['az', 'Азербайджанский'], ['tr', 'Турецкий'], ['en', 'Английский']];
    view('<div class="card glass"><h3>Нейро-голос</h3>' + sw('ttsOn', 'Нейро-голос включён', c.ttsEnabled) +
      '<div class="note ' + (c.hasAzureKey ? 'ok' : 'bad') + '">' + (c.hasAzureKey ? 'Сервис речи подключён.' : 'Сервис речи не подключён (раздел «API и интеграции»). Приложения используют системный голос телефона.') + '</div>' +
      L.map(l => row(l[1] + ': имя голоса', txt('v_' + l[0], c.voices[l[0]]))).join('') +
      row('Скорость речи, % (от −30 до 30)', num('rate', c.voiceRate), 'Мужские голоса по умолчанию: ru-RU-DmitryNeural, az-AZ-BabekNeural, tr-TR-AhmetNeural, en-US-GuyNeural. Пустое поле вернёт значение по умолчанию. Если имя неверно, сервис речи вернёт ошибку.') +
      '<div class="row"><button class="btn primary" id="saveV">Сохранить</button></div>' + out('vo') +
      '<div class="seg" style="margin-top:12px">' + L.map(l => '<button class="btn ghost" data-t="' + l[0] + '">Проверить ' + l[0].toUpperCase() + '</button>').join('') + '</div></div>' +
      '<div class="note dim">Выбор между системным и нейро-голосом пользователь делает в приложении (Настройки → Голос).</div>');
    $('#saveV').onclick = function () { guarded(this, async () => { const v = {}; L.forEach(l => { v[l[0]] = val('v_' + l[0]); }); await save({ ttsEnabled: $('#ttsOn').checked, voices: v, voiceRate: optNum('rate') }, 'vo'); }); };
    document.querySelectorAll('[data-t]').forEach(b => { b.onclick = () => guarded(b, async () => { say('vo', true, 'Проверяю…'); const r = await api('POST', '/admin/test-tts', { lang: b.dataset.t }); if (!r.ok) say('vo', false, errText(r)); else say('vo', !!r.data.ok, (r.data.voice ? r.data.voice + ': ' : '') + r.data.message); }); });
  }

  /* ---------- Настройки JARVIS ---------- */
  async function pageApp() {
    const c = await loadCfg(); if (!c) return; const f = c.features || {};
    view('<div class="card glass"><h3>Объявление и режим работ</h3>' + row('Объявление для пользователей (показывается при запуске)', '<textarea id="ann" class="field" rows="3" maxlength="500">' + esc(c.announcement) + '</textarea>') +
      sw('maint', 'Режим технических работ (бесплатный режим временно недоступен)', c.maintenance) +
      '<div class="row"><button class="btn primary" id="saveA">Сохранить</button></div>' + out('so') + '</div>' +
      '<div class="card glass"><h3>Функции приложения</h3>' + sw('f_gmail', 'Gmail', f.gmail !== false) + sw('f_screen', 'Показ экрана', f.screenShare !== false) + sw('f_tts', 'Нейро-голос', f.onlineTts !== false) +
      '<div class="row"><button class="btn primary" id="saveF">Сохранить</button></div>' + out('fo') +
      '<div class="note dim">Приложения получают эти параметры при запуске и применяют их. Функцию, которой в сборке приложения нет, включить нельзя.</div></div>');
    $('#saveA').onclick = function () { guarded(this, async () => { if ($('#maint').checked && !c.maintenance && !(await ask('Включить режим технических работ? Бесплатный режим перестанет отвечать пользователям.', 'Включить'))) return; await save({ announcement: $('#ann').value, maintenance: $('#maint').checked }, 'so'); }); };
    $('#saveF').onclick = function () { guarded(this, async () => { await save({ features: { gmail: $('#f_gmail').checked, screenShare: $('#f_screen').checked, onlineTts: $('#f_tts').checked } }, 'fo'); }); };
  }

  /* ---------- Журналы и диагностика ---------- */
  let logLevel = '';
  async function pageLogs() {
    const [d, l] = await Promise.all([api('GET', '/admin/diagnostics'), api('GET', '/admin/logs?limit=150' + (logLevel ? '&level=' + logLevel : ''))]);
    const dg = d.ok ? d.data : null; const rows = l.ok ? l.data.logs : [];
    const yn = v => v ? 'да' : 'нет';
    view('<div class="card glass"><h3>Состояние сервера</h3>' + (dg ? '<div class="kv"><span>Версия</span><span>' + esc(dg.version) + '</span><span>Работает</span><span>' + Math.floor(dg.uptimeSec / 60) + ' мин</span><span>Память</span><span>' + dg.memoryMB + ' МБ</span><span>Пользователей</span><span>' + dg.users + '</span><span>Файл данных</span><span>' + Math.round(dg.dataFileBytes / 1024) + ' КБ</span><span>Активных запросов</span><span>' + dg.activeChats + '</span><span>Ключ ИИ задан</span><span>' + yn(dg.keyConfigured) + '</span><span>Нейро-голос</span><span>' + yn(dg.ttsAvailable) + '</span><span>Google-вход на сервере</span><span>' + yn(dg.googleConfigured) + '</span><span>Ошибок за час</span><span>' + dg.errorsLastHour + '</span><span>Режим админ-API</span><span>' + esc(dg.adminMode) + '</span></div>' : '<div class="note bad">' + esc(errText(d)) + '</div>') + '</div>' +
      '<div class="card glass"><h3>Журнал событий</h3><div class="seg">' + [['', 'Все'], ['error', 'Ошибки'], ['warn', 'Предупр.'], ['info', 'Инфо']].map(x => '<button class="chip' + (logLevel === x[0] ? ' on' : '') + '" data-lv="' + x[0] + '">' + x[1] + '</button>').join('') + '</div>' +
      (rows.length ? rows.map(r => '<div class="logrow ' + esc(r.level) + '">' + esc(r.message) + '<small>' + new Date(r.t).toLocaleString() + ' · ' + esc(r.type) + (r.user ? ' · ' + esc(r.user) : '') + (r.by ? ' · ' + esc(r.by) : '') + '</small></div>').join('') : '<div class="empty-note">Событий нет</div>') +
      '<div class="row"><button class="btn ghost" id="refresh">Обновить</button><button class="btn danger" id="clearLogs">Очистить</button></div><div class="note dim">В журнале нет ключей и текстов сообщений. Он хранится в памяти сервера и сбрасывается при перезапуске.</div></div>');
    document.querySelectorAll('[data-lv]').forEach(b => { b.onclick = () => { logLevel = b.dataset.lv; pageLogs(); }; });
    $('#refresh').onclick = () => pageLogs();
    $('#clearLogs').onclick = function () { guarded(this, async () => { if (!(await ask('Очистить журнал событий?', 'Очистить'))) return; await api('DELETE', '/admin/logs'); pageLogs(); }); };
  }

  /* ---------- Система ---------- */
  async function pageSystem() {
    view('<div class="card glass"><h3>Сервер JARVIS</h3>' + row('Адрес сервера (https://…)', txt('host', S.host, 'https://jarvis.example.com')) +
      '<div class="row"><button class="btn primary" id="saveHost">Сохранить и проверить</button><button class="btn danger" id="forget">Забыть</button></div>' + out('so') +
      '<div class="note dim">Это адрес твоего сервера (папка backend). Пароли и ключи в приложении не хранятся.</div></div>' +
      '<div class="card glass"><h3>Доступ</h3><div class="kv"><span>Режим админ-API на сервере</span><span>' + esc(S.adminMode || '—') + '</span><span>Подключение</span><span>' + (S.connected ? 'есть' : 'нет') + '</span></div>' +
      '<div class="note">В этой версии панель открывается без входа. Защита данных обеспечивается сервером: режим «open» нужен только на этапе настройки, затем включается режим «google» (вход администратора). Панель уже использует общие маршруты /admin/*, поэтому защита добавляется на сервере без переделки приложения.</div></div>');
    $('#saveHost').onclick = function () { guarded(this, async () => {
      const h = val('host');
      if (!native('saveServer', h)) { say('so', false, 'Адрес должен начинаться с https://'); return; }
      S.host = safeJson(native('getState'), {}).backendUrl || h; $('#host').value = S.host;
      say('so', true, 'Проверяю подключение…');
      const ok = await connect(false);
      say('so', ok, ok ? 'Подключено к ' + S.host : (S.authIssue ? 'Сервер найден, но закрывает админ-доступ: включи на нём ADMIN_MODE=open.' : 'Сервер не отвечает по этому адресу.'));
    }); };
    $('#forget').onclick = function () { guarded(this, async () => { if (!(await ask('Забыть адрес сервера?', 'Забыть'))) return; native('clearServer'); S.host = ''; S.connected = false; setConn('', 'нет сервера'); pageSystem(); }); };
  }

  const PAGE_FN = { users: pageUsers, limits: pageLimits, ai: pageAi, integrations: pageIntegrations, voice: pageVoice, appsettings: pageApp, logs: pageLogs, system: pageSystem };

  /* ---------- события и запуск ---------- */
  window.AdminEvents = { emit: function (name, json) { if (name === 'api') { const d = safeJson(json, {}); const f = pending[d.reqId]; if (f) { delete pending[d.reqId]; f({ ok: !!d.ok, status: d.status, code: d.code, data: safeJson(d.body, null) }); } } } };
  window.adminBack = () => { if (!$('#dialog').hidden) { $('#dialogNo').click(); return true; } if (S.page !== 'home') { showHome(); return true; } return false; };
  $('#back').innerHTML = ic('back', 22); $('#back').onclick = () => showHome();
  (async function init() {
    S.host = (safeJson(native('getState'), {}) || {}).backendUrl || '';
    showHome();                       // панель открывается сразу, не дожидаясь сети
    if (S.host) { await connect(true); if (S.page === 'home') showHome(); }
  })();
})();
